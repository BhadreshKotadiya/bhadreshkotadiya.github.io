/**
 * Modern Portfolio - Enhanced JavaScript
 * Dark Mode Toggle & Animations
 */

(function() {
  'use strict';

  // ============================================
  // DARK MODE TOGGLE
  // ============================================
  const initThemeToggle = () => {
    const themeToggle = document.getElementById('theme-toggle');
    const themeIcon = document.getElementById('theme-icon');
    const body = document.body;
    
    // Check for saved theme preference or default to light mode
    const savedTheme = localStorage.getItem('theme') || 'light';
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    // Set initial theme
    if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
      body.classList.add('theme-dark');
      body.classList.remove('theme-light');
      if (themeIcon) {
        themeIcon.classList.remove('fa-moon');
        themeIcon.classList.add('fa-sun');
      }
    } else {
      body.classList.add('theme-light');
      body.classList.remove('theme-dark');
      if (themeIcon) {
        themeIcon.classList.remove('fa-sun');
        themeIcon.classList.add('fa-moon');
      }
    }
    
    // Toggle theme on button click
    if (themeToggle) {
      themeToggle.addEventListener('click', () => {
        const isDark = body.classList.contains('theme-dark');
        
        if (isDark) {
          body.classList.remove('theme-dark');
          body.classList.add('theme-light');
          localStorage.setItem('theme', 'light');
          if (themeIcon) {
            themeIcon.classList.remove('fa-sun');
            themeIcon.classList.add('fa-moon');
          }
        } else {
          body.classList.remove('theme-light');
          body.classList.add('theme-dark');
          localStorage.setItem('theme', 'dark');
          if (themeIcon) {
            themeIcon.classList.remove('fa-moon');
            themeIcon.classList.add('fa-sun');
          }
        }
        
        // Add smooth transition class temporarily
        body.style.transition = 'background-color 0.3s ease, color 0.3s ease';
        setTimeout(() => {
          body.style.transition = '';
        }, 300);
      });
    }
  };

  // ============================================
  // MOBILE MENU TOGGLE
  // ============================================
  const initMobileMenu = () => {
    const mobileMenuButton = document.getElementById('mobile-menu');
    const navMenu = document.getElementById('nav-menu');
    
    if (mobileMenuButton && navMenu) {
      mobileMenuButton.addEventListener('click', () => {
        navMenu.classList.toggle('active');
        const icon = mobileMenuButton.querySelector('i');
        if (icon) {
          if (navMenu.classList.contains('active')) {
            icon.classList.remove('fa-bars');
            icon.classList.add('fa-times');
          } else {
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
          }
        }
      });
      
      // Close mobile menu when a link is clicked
      const navLinks = navMenu.querySelectorAll('a');
      navLinks.forEach((link) => {
        link.addEventListener('click', () => {
          if (navMenu.classList.contains('active')) {
            navMenu.classList.remove('active');
            const icon = mobileMenuButton.querySelector('i');
            if (icon) {
              icon.classList.remove('fa-times');
              icon.classList.add('fa-bars');
            }
          }
        });
      });
      
      // Close menu when clicking outside
      document.addEventListener('click', (e) => {
        if (!navMenu.contains(e.target) && !mobileMenuButton.contains(e.target)) {
          navMenu.classList.remove('active');
          const icon = mobileMenuButton.querySelector('i');
          if (icon) {
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
          }
        }
      });
    }
  };

  // ============================================
  // SMOOTH SCROLL & ACTIVE NAVIGATION
  // ============================================
  const initSmoothScroll = () => {
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        if (href === '#' || href === '#!') return;
        
        e.preventDefault();
        const target = document.querySelector(href);
        if (target) {
          const headerOffset = 80;
          const elementPosition = target.getBoundingClientRect().top;
          const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
          
          window.scrollTo({
            top: offsetPosition,
            behavior: 'smooth'
          });
        }
      });
    });
    
    // Active link highlighting on scroll
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-links a');
    
    const updateActiveLink = () => {
      let current = '';
      const scrollPosition = window.pageYOffset + 150;
      
      sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
          current = section.getAttribute('id');
        }
      });
      
      navLinks.forEach(link => {
        link.classList.remove('active');
        const href = link.getAttribute('href');
        if (href === `#${current}`) {
          link.classList.add('active');
        }
      });
      
      // Handle hero section
      if (window.pageYOffset < 100) {
        navLinks.forEach(link => {
          link.classList.remove('active');
          if (link.getAttribute('href') === '#hero') {
            link.classList.add('active');
          }
        });
      }
    };
    
    window.addEventListener('scroll', updateActiveLink);
    updateActiveLink(); // Initial call
  };

  // ============================================
  // SCROLL REVEAL ANIMATIONS
  // ============================================
  const initScrollReveal = () => {
    const scrollAnimatedElements = document.querySelectorAll('.scroll-animate');
    
    const scrollObserver = new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const delay = entry.target.dataset.animDelay || '0s';
            entry.target.style.transitionDelay = delay;
            entry.target.classList.add('revealed');
            observer.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
      }
    );
    
    scrollAnimatedElements.forEach((el) => {
      scrollObserver.observe(el);
    });
  };

  // ============================================
  // HEADER SCROLL EFFECT
  // ============================================
  const initHeaderScroll = () => {
    const header = document.querySelector('.header-glass');
    let lastScroll = 0;
    
    window.addEventListener('scroll', () => {
      const currentScroll = window.pageYOffset;
      
      if (currentScroll > 100) {
        if (header) {
          header.style.boxShadow = '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)';
        }
      } else {
        if (header) {
          header.style.boxShadow = '0 1px 2px 0 rgba(0, 0, 0, 0.05)';
        }
      }
      
      lastScroll = currentScroll;
    });
  };

  // ============================================
  // CONTACT FORM HANDLING
  // ============================================
  const initContactForm = () => {
    const contactForm = document.getElementById('contact-form');
    const formMessage = document.getElementById('form-message');
    
    if (contactForm) {
      contactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const submitButton = contactForm.querySelector('button[type="submit"]');
        const originalText = submitButton.innerHTML;
        
        // Disable button and show loading state
        submitButton.disabled = true;
        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
        
        try {
          const formData = new FormData(contactForm);
          const response = await fetch(contactForm.action, {
            method: 'POST',
            body: formData,
            headers: {
              Accept: 'application/json'
            }
          });
          
          if (response.ok) {
            if (formMessage) {
              formMessage.style.color = 'var(--primary-color)';
              formMessage.textContent = 'Message sent successfully! Thank you for reaching out.';
            }
            contactForm.reset();
          } else {
            const errorData = await response.json();
            if (formMessage) {
              formMessage.style.color = '#ef4444';
              formMessage.textContent = errorData.error || 'Something went wrong. Please try again.';
            }
          }
        } catch (error) {
          if (formMessage) {
            formMessage.style.color = '#ef4444';
            formMessage.textContent = 'An error occurred. Please try again.';
          }
        } finally {
          submitButton.disabled = false;
          submitButton.innerHTML = originalText;
          
          if (formMessage) {
            setTimeout(() => {
              formMessage.textContent = '';
            }, 5000);
          }
        }
      });
    }
  };

  // ============================================
  // PARALLAX EFFECT FOR HERO
  // ============================================
  const initParallax = () => {
    const hero = document.getElementById('hero');
    if (!hero) return;
    
    window.addEventListener('scroll', () => {
      const scrolled = window.pageYOffset;
      const heroContent = hero.querySelector('.hero-content');
      
      if (heroContent && scrolled < window.innerHeight) {
        heroContent.style.transform = `translateY(${scrolled * 0.5}px)`;
        heroContent.style.opacity = 1 - (scrolled / window.innerHeight) * 0.5;
      }
    });
  };

  // ============================================
  // SET CURRENT YEAR IN FOOTER
  // ============================================
  const setCurrentYear = () => {
    const yearElement = document.getElementById('currentYear');
    if (yearElement) {
      yearElement.textContent = new Date().getFullYear();
    }
  };

  // ============================================
  // INITIALIZE ALL FEATURES
  // ============================================
  const init = () => {
    // Wait for DOM to be fully loaded
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        initThemeToggle();
        initMobileMenu();
        initSmoothScroll();
        initScrollReveal();
        initHeaderScroll();
        initContactForm();
        setCurrentYear();
        
        // Initialize parallax after a short delay
        setTimeout(initParallax, 100);
      });
    } else {
      // DOM already loaded
      initThemeToggle();
      initMobileMenu();
      initSmoothScroll();
      initScrollReveal();
      initHeaderScroll();
      initContactForm();
      setCurrentYear();
      setTimeout(initParallax, 100);
    }
  };

  // Start initialization
  init();
})();

